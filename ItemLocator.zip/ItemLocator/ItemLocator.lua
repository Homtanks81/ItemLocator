--[[
	ItemLocator
	Shows how many of an item you have across every character on this
	account (that you've played since installing this addon), broken
	down by bags / bank / mailbox.

	Slash commands:
		/il scan   - force a rescan of bags (and bank, if open) right now
		/il reset  - wipe all saved data for every character
]]

----------------------------------------------------------------------------
-- Database
----------------------------------------------------------------------------

ItemLocatorDB = ItemLocatorDB or {}
ItemLocatorDB.names = ItemLocatorDB.names or {}
ItemLocatorDB.knownChars = ItemLocatorDB.knownChars or {}

local CHAR_KEY = UnitName("player") .. "-" .. GetRealmName()

local function EnsureDataFor(key)
	if not ItemLocatorDB[key] then
		ItemLocatorDB[key] = { bags = {}, bank = {}, mail = {}, transit = {}, equipped = {} }
	end
	ItemLocatorDB[key].transit = ItemLocatorDB[key].transit or {}
	ItemLocatorDB[key].equipped = ItemLocatorDB[key].equipped or {}
	return ItemLocatorDB[key]
end

local function EnsureCharData()
	return EnsureDataFor(CHAR_KEY)
end

-- Normalizes a typed recipient name to match the proper-case form the
-- game itself uses for UnitName(), so "bob" and "Bob" resolve to the
-- same saved-data key.
local function NormalizeName(name)
	if not name or name == "" then return name end
	name = string.gsub(name, "^%s+", "")
	name = string.gsub(name, "%s+$", "")
	return string.upper(string.sub(name, 1, 1)) .. string.lower(string.sub(name, 2))
end

local function GetItemIDFromLink(link)
	if not link then return nil end
	local id = string.match(link, "item:(%d+)")
	return id and tonumber(id) or nil
end

local function RememberName(itemID, link)
	if itemID and link and not ItemLocatorDB.names[itemID] then
		ItemLocatorDB.names[itemID] = link
	end
end

----------------------------------------------------------------------------
-- Scanning
----------------------------------------------------------------------------

local function ScanContainer(bag, counts)
	local slots = GetContainerNumSlots(bag)
	if not slots or slots == 0 then return end
	for slot = 1, slots do
		local link = GetContainerItemLink(bag, slot)
		if link then
			local itemID = GetItemIDFromLink(link)
			if itemID then
				local _, itemCount = GetContainerItemInfo(bag, slot)
				itemCount = itemCount or 1
				counts[itemID] = (counts[itemID] or 0) + itemCount
				RememberName(itemID, link)
			end
		end
	end
end

local NUM_BAG_SLOTS = NUM_BAG_SLOTS or 4
local BANK_CONTAINER = BANK_CONTAINER or -1
local NUM_BANKBAGSLOTS = NUM_BANKBAGSLOTS or 6

local function ScanBags()
	local data = EnsureCharData()
	local counts = {}
	for bag = 0, NUM_BAG_SLOTS do
		ScanContainer(bag, counts)
	end
	data.bags = counts
end

local function ScanBank()
	if not BankFrame or not BankFrame:IsVisible() then return end
	local data = EnsureCharData()
	local counts = {}

	-- Main bank storage
	ScanContainer(BANK_CONTAINER, counts)

	-- Purchased bank bags
	for bag = NUM_BAG_SLOTS + 1, NUM_BAG_SLOTS + NUM_BANKBAGSLOTS do
		ScanContainer(bag, counts)
	end

	data.bank = counts
end

local INVSLOT_FIRST_EQUIPPED = INVSLOT_FIRST_EQUIPPED or 1
local INVSLOT_LAST_EQUIPPED = INVSLOT_LAST_EQUIPPED or 19

local function ScanEquipped()
	local data = EnsureCharData()
	local counts = {}
	for slot = INVSLOT_FIRST_EQUIPPED, INVSLOT_LAST_EQUIPPED do
		local link = GetInventoryItemLink("player", slot)
		if link then
			local itemID = GetItemIDFromLink(link)
			if itemID then
				counts[itemID] = (counts[itemID] or 0) + 1
				RememberName(itemID, link)
			end
		end
	end
	data.equipped = counts
end

local function ScanMail()
	if not GetInboxNumItems then return end
	local data = EnsureCharData()
	local counts = {}
	local numItems = GetInboxNumItems()
	local maxAttachments = ATTACHMENTS_MAX_RECEIVE or 12
	for mailIndex = 1, numItems do
		for attachIndex = 1, maxAttachments do
			local link = GetInboxItemLink(mailIndex, attachIndex)
			if link then
				local itemID = GetItemIDFromLink(link)
				if itemID then
					local _, _, itemCount = GetInboxItem(mailIndex, attachIndex)
					itemCount = itemCount or 1
					counts[itemID] = (counts[itemID] or 0) + itemCount
					RememberName(itemID, link)
				end
			end
		end
	end
	data.mail = counts

	-- We just saw our own mailbox contents directly, so any "in transit"
	-- entries addressed to us are now stale (either still sitting in the
	-- mail we just scanned, or already picked up into bags) - clear them.
	data.transit = {}
end

----------------------------------------------------------------------------
-- Outgoing mail (in-transit tracking)
----------------------------------------------------------------------------

-- Captures what you're mailing, and to whom, at the moment you hit Send -
-- so the recipient's totals update immediately without needing to log
-- into them and open their mailbox first.

local ATTACHMENTS_MAX_SEND = ATTACHMENTS_MAX_SEND or 12

local orig_SendMail = SendMail
SendMail = function(recipient, subject, body)
	if recipient and recipient ~= "" and GetSendMailItemLink then
		local targetName = NormalizeName(recipient)
		local targetKey = targetName
		if not string.find(targetKey, "-") then
			targetKey = targetKey .. "-" .. GetRealmName()
		end

		-- Only track as "in transit" if this recipient is known to share
		-- this same saved-data file (i.e. has actually logged in through
		-- it before). Otherwise the entry would have no way to ever be
		-- cleared, and would sit there permanently stale.
		ItemLocatorDB.knownChars = ItemLocatorDB.knownChars or {}
		if ItemLocatorDB.knownChars[targetKey] then
			local targetData = EnsureDataFor(targetKey)

			for i = 1, ATTACHMENTS_MAX_SEND do
				local link = GetSendMailItemLink(i)
				if link then
					local itemID = GetItemIDFromLink(link)
					if itemID then
						local _, _, count = GetSendMailItem(i)
						count = count or 1
						targetData.transit[itemID] = (targetData.transit[itemID] or 0) + count
						RememberName(itemID, link)
					end
				end
			end
		end
	end

	orig_SendMail(recipient, subject, body)
end

----------------------------------------------------------------------------
-- Events
----------------------------------------------------------------------------

-- Forward-declared here so the PLAYER_LOGIN handler below can call it;
-- its actual definition lives in the Tooltip augmentation section further
-- down, once HookItemTooltips exists.
local HookAtlasLootTooltips

local bankOpen = false

local scanFrame = CreateFrame("Frame")
scanFrame:RegisterEvent("PLAYER_LOGIN")
scanFrame:RegisterEvent("BAG_UPDATE")
scanFrame:RegisterEvent("BANKFRAME_OPENED")
scanFrame:RegisterEvent("BANKFRAME_CLOSED")
scanFrame:RegisterEvent("MAIL_SHOW")
scanFrame:RegisterEvent("MAIL_INBOX_UPDATE")
scanFrame:RegisterEvent("UNIT_INVENTORY_CHANGED")

scanFrame:SetScript("OnEvent", function()
	if event == "PLAYER_LOGIN" then
		-- Being able to log in here at all, through this saved-data file,
		-- is proof this character's data genuinely lands in this same
		-- file - so it's safe to treat as a valid in-transit destination.
		ItemLocatorDB.knownChars[CHAR_KEY] = true
		ScanBags()
		ScanEquipped()
		HookAtlasLootTooltips()
	elseif event == "BAG_UPDATE" then
		ScanBags()
		if bankOpen then ScanBank() end
	elseif event == "BANKFRAME_OPENED" then
		bankOpen = true
		ScanBank()
	elseif event == "BANKFRAME_CLOSED" then
		bankOpen = false
	elseif event == "MAIL_SHOW" or event == "MAIL_INBOX_UPDATE" then
		ScanMail()
	elseif event == "UNIT_INVENTORY_CHANGED" then
		if arg1 == "player" then
			ScanEquipped()
		end
	end
end)

-- Safety net: BAG_UPDATE should fire the instant something moves between
-- bags and bank, but as a backstop (in case that event fires unreliably
-- for bank containers on this client), also poll a couple times a second
-- while the bank window is actually open. This guarantees the tooltip
-- never shows more than a fraction of a second of stale bank data.
local BANK_POLL_INTERVAL = 0.5
local pollElapsed = 0

scanFrame:SetScript("OnUpdate", function()
	if not bankOpen then return end
	local elapsed = arg1 or 0
	pollElapsed = pollElapsed + elapsed
	if pollElapsed >= BANK_POLL_INTERVAL then
		pollElapsed = 0
		ScanBank()
		ScanBags()
	end
end)

----------------------------------------------------------------------------
-- Tooltip augmentation
----------------------------------------------------------------------------

local function BuildInfoLines(tooltip, itemID)
	if not itemID then return end

	local rows = {}
	local grandTotal = 0
	for charKey, data in pairs(ItemLocatorDB) do
		if charKey ~= "names" then
			local bags = (data.bags and data.bags[itemID]) or 0
			local bank = (data.bank and data.bank[itemID]) or 0
			local mail = (data.mail and data.mail[itemID]) or 0
			local transit = (data.transit and data.transit[itemID]) or 0
			local equipped = (data.equipped and data.equipped[itemID]) or 0
			local total = bags + bank + mail + transit + equipped
			if total > 0 then
				grandTotal = grandTotal + total
				local parts = {}
				if bags > 0 then table.insert(parts, bags .. " bags") end
				if bank > 0 then table.insert(parts, bank .. " bank") end
				if mail > 0 then table.insert(parts, mail .. " mail") end
				if transit > 0 then table.insert(parts, transit .. " in transit") end
				if equipped > 0 then table.insert(parts, equipped .. " equipped") end
				table.insert(rows, string.format("  %s: %d (%s)", charKey, total, table.concat(parts, ", ")))
			end
		end
	end

	if grandTotal == 0 then return end

	tooltip:AddLine(" ")
	tooltip:AddLine(string.format("Item Locator - Account Total: %d", grandTotal), 1, 0.82, 0)
	for _, line in ipairs(rows) do
		tooltip:AddLine(line, 1, 1, 1)
	end
	tooltip:Show()
end

-- Vanilla has no unified "OnTooltipSetItem" hook, so each tooltip source
-- function is individually wrapped to append our info after the original
-- tooltip content is built. This wrapping is applied to a given tooltip
-- object (usually GameTooltip, but AtlasLoot's own tooltip objects get
-- the same treatment further below) so third-party addons that use their
-- own tooltip frame still get covered.

local function HookItemTooltips(tooltip)
	if not tooltip or tooltip.__ItemLocatorHooked then return end
	tooltip.__ItemLocatorHooked = true

	if tooltip.SetBagItem then
		local orig = tooltip.SetBagItem
		tooltip.SetBagItem = function(self, bag, slot)
			orig(self, bag, slot)
			BuildInfoLines(self, GetItemIDFromLink(GetContainerItemLink(bag, slot)))
		end
	end

	if tooltip.SetInventoryItem then
		local orig = tooltip.SetInventoryItem
		tooltip.SetInventoryItem = function(self, unit, slot)
			orig(self, unit, slot)
			BuildInfoLines(self, GetItemIDFromLink(GetInventoryItemLink(unit, slot)))
		end
	end

	if tooltip.SetHyperlink then
		local orig = tooltip.SetHyperlink
		tooltip.SetHyperlink = function(self, link)
			orig(self, link)
			BuildInfoLines(self, GetItemIDFromLink(link))
		end
	end

	if tooltip.SetMerchantItem then
		local orig = tooltip.SetMerchantItem
		tooltip.SetMerchantItem = function(self, index)
			orig(self, index)
			BuildInfoLines(self, GetItemIDFromLink(GetMerchantItemLink(index)))
		end
	end

	if tooltip.SetLootItem then
		local orig = tooltip.SetLootItem
		tooltip.SetLootItem = function(self, slot)
			orig(self, slot)
			BuildInfoLines(self, GetItemIDFromLink(GetLootSlotLink(slot)))
		end
	end

	if tooltip.SetInboxItem then
		local orig = tooltip.SetInboxItem
		tooltip.SetInboxItem = function(self, mailIndex, attachIndex)
			orig(self, mailIndex, attachIndex)
			BuildInfoLines(self, GetItemIDFromLink(GetInboxItemLink(mailIndex, attachIndex or 1)))
		end
	end

	if tooltip.SetAuctionItem then
		local orig = tooltip.SetAuctionItem
		tooltip.SetAuctionItem = function(self, listType, index)
			orig(self, listType, index)
			BuildInfoLines(self, GetItemIDFromLink(GetAuctionItemLink(listType, index)))
		end
	end

	-- Trade skill window (Smelting, and every other profession recipe list).
	-- Covers both the crafted result icon (reagentIndex omitted) and each
	-- individual reagent icon shown in a recipe's details (reagentIndex set).
	if tooltip.SetTradeSkillItem then
		local orig = tooltip.SetTradeSkillItem
		tooltip.SetTradeSkillItem = function(self, skillIndex, reagentIndex)
			orig(self, skillIndex, reagentIndex)
			local link
			if reagentIndex then
				link = GetTradeSkillReagentItemLink(skillIndex, reagentIndex)
			else
				link = GetTradeSkillItemLink(skillIndex)
			end
			BuildInfoLines(self, GetItemIDFromLink(link))
		end
	end

	-- Older-style "Craft" window used by a handful of profession UIs.
	if tooltip.SetCraftItem then
		local orig = tooltip.SetCraftItem
		tooltip.SetCraftItem = function(self, skillIndex, reagentIndex)
			orig(self, skillIndex, reagentIndex)
			local link
			if reagentIndex and GetCraftReagentItemLink then
				link = GetCraftReagentItemLink(skillIndex, reagentIndex)
			elseif GetCraftItemLink then
				link = GetCraftItemLink(skillIndex)
			end
			BuildInfoLines(self, GetItemIDFromLink(link))
		end
	end
end

HookItemTooltips(GameTooltip)

-- AtlasLoot (TW Edition) draws its item tooltips using its own tooltip
-- objects - AtlasLootTooltip and AtlasLootTooltip2 - instead of the shared
-- GameTooltip, so the hooks above never see them. Since those objects are
-- built from the same GameTooltip template, they support the same Set*
-- methods, so we apply the identical wrapping to them specifically. This
-- runs on PLAYER_LOGIN (rather than immediately) so it's not a problem if
-- ItemLocator's file happens to load before AtlasLoot's.
HookAtlasLootTooltips = function()
	if AtlasLootTooltip then HookItemTooltips(AtlasLootTooltip) end
	if AtlasLootTooltip2 then HookItemTooltips(AtlasLootTooltip2) end
end

----------------------------------------------------------------------------
-- Slash commands
----------------------------------------------------------------------------

SLASH_ITEMLOCATOR1 = "/itemlocator"
SLASH_ITEMLOCATOR2 = "/il"
SlashCmdList["ITEMLOCATOR"] = function(msg)
	msg = string.lower(msg or "")
	if msg == "scan" then
		ScanBags()
		ScanEquipped()
		if BankFrame and BankFrame:IsVisible() then ScanBank() end
		DEFAULT_CHAT_FRAME:AddMessage("ItemLocator: rescanned.")
	elseif msg == "reset" then
		ItemLocatorDB = { names = {}, knownChars = {} }
		DEFAULT_CHAT_FRAME:AddMessage("ItemLocator: all saved data cleared.")
	else
		DEFAULT_CHAT_FRAME:AddMessage("ItemLocator commands: /il scan, /il reset")
	end
end
