--[[
	ItemLocator
	Shows how many of an item you have across every character on this
	account (that you've played since installing this addon), broken
	down by bags / bank / mailbox.

	Slash commands:
		/il scan   - force a rescan of bags (and bank, if open) right now
		/il reset  - wipe all saved data for every character
]]

----------------------------------------------------------------------------
-- Database
----------------------------------------------------------------------------

ItemLocatorDB = ItemLocatorDB or {}
ItemLocatorDB.names = ItemLocatorDB.names or {}

local CHAR_KEY = UnitName("player") .. "-" .. GetRealmName()

local function EnsureDataFor(key)
	if not ItemLocatorDB[key] then
		ItemLocatorDB[key] = { bags = {}, bank = {}, mail = {}, transit = {} }
	end
	ItemLocatorDB[key].transit = ItemLocatorDB[key].transit or {}
	return ItemLocatorDB[key]
end

local function EnsureCharData()
	return EnsureDataFor(CHAR_KEY)
end

-- Normalizes a typed recipient name to match the proper-case form the
-- game itself uses for UnitName(), so "bob" and "Bob" resolve to the
-- same saved-data key.
local function NormalizeName(name)
	if not name or name == "" then return name end
	name = string.gsub(name, "^%s+", "")
	name = string.gsub(name, "%s+$", "")
	return string.upper(string.sub(name, 1, 1)) .. string.lower(string.sub(name, 2))
end

local function GetItemIDFromLink(link)
	if not link then return nil end
	local id = string.match(link, "item:(%d+)")
	return id and tonumber(id) or nil
end

local function RememberName(itemID, link)
	if itemID and link and not ItemLocatorDB.names[itemID] then
		ItemLocatorDB.names[itemID] = link
	end
end

----------------------------------------------------------------------------
-- Scanning
----------------------------------------------------------------------------

local function ScanContainer(bag, counts)
	local slots = GetContainerNumSlots(bag)
	if not slots or slots == 0 then return end
	for slot = 1, slots do
		local link = GetContainerItemLink(bag, slot)
		if link then
			local itemID = GetItemIDFromLink(link)
			if itemID then
				local _, itemCount = GetContainerItemInfo(bag, slot)
				itemCount = itemCount or 1
				counts[itemID] = (counts[itemID] or 0) + itemCount
				RememberName(itemID, link)
			end
		end
	end
end

local NUM_BAG_SLOTS = NUM_BAG_SLOTS or 4
local BANK_CONTAINER = BANK_CONTAINER or -1
local NUM_BANKBAGSLOTS = NUM_BANKBAGSLOTS or 6

local function ScanBags()
	local data = EnsureCharData()
	local counts = {}
	for bag = 0, NUM_BAG_SLOTS do
		ScanContainer(bag, counts)
	end
	data.bags = counts
end

local function ScanBank()
	if not BankFrame or not BankFrame:IsVisible() then return end
	local data = EnsureCharData()
	local counts = {}

	-- Main bank storage
	ScanContainer(BANK_CONTAINER, counts)

	-- Purchased bank bags
	for bag = NUM_BAG_SLOTS + 1, NUM_BAG_SLOTS + NUM_BANKBAGSLOTS do
		ScanContainer(bag, counts)
	end

	data.bank = counts
end

local function ScanMail()
	if not GetInboxNumItems then return end
	local data = EnsureCharData()
	local counts = {}
	local numItems = GetInboxNumItems()
	local maxAttachments = ATTACHMENTS_MAX_RECEIVE or 12
	for mailIndex = 1, numItems do
		for attachIndex = 1, maxAttachments do
			local link = GetInboxItemLink(mailIndex, attachIndex)
			if link then
				local itemID = GetItemIDFromLink(link)
				if itemID then
					local _, _, itemCount = GetInboxItem(mailIndex, attachIndex)
					itemCount = itemCount or 1
					counts[itemID] = (counts[itemID] or 0) + itemCount
					RememberName(itemID, link)
				end
			end
		end
	end
	data.mail = counts

	-- We just saw our own mailbox contents directly, so any "in transit"
	-- entries addressed to us are now stale (either still sitting in the
	-- mail we just scanned, or already picked up into bags) - clear them.
	data.transit = {}
end

----------------------------------------------------------------------------
-- Outgoing mail (in-transit tracking)
----------------------------------------------------------------------------

-- Captures what you're mailing, and to whom, at the moment you hit Send -
-- so the recipient's totals update immediately without needing to log
-- into them and open their mailbox first.

local ATTACHMENTS_MAX_SEND = ATTACHMENTS_MAX_SEND or 12

local orig_SendMail = SendMail
SendMail = function(recipient, subject, body)
	if recipient and recipient ~= "" and GetSendMailItemLink then
		local targetName = NormalizeName(recipient)
		local targetKey = targetName
		if not string.find(targetKey, "-") then
			targetKey = targetKey .. "-" .. GetRealmName()
		end
		local targetData = EnsureDataFor(targetKey)

		for i = 1, ATTACHMENTS_MAX_SEND do
			local link = GetSendMailItemLink(i)
			if link then
				local itemID = GetItemIDFromLink(link)
				if itemID then
					local _, _, count = GetSendMailItem(i)
					count = count or 1
					targetData.transit[itemID] = (targetData.transit[itemID] or 0) + count
					RememberName(itemID, link)
				end
			end
		end
	end

	orig_SendMail(recipient, subject, body)
end

----------------------------------------------------------------------------
-- Events
----------------------------------------------------------------------------

local bankOpen = false

local scanFrame = CreateFrame("Frame")
scanFrame:RegisterEvent("PLAYER_LOGIN")
scanFrame:RegisterEvent("BAG_UPDATE")
scanFrame:RegisterEvent("BANKFRAME_OPENED")
scanFrame:RegisterEvent("BANKFRAME_CLOSED")
scanFrame:RegisterEvent("MAIL_SHOW")
scanFrame:RegisterEvent("MAIL_INBOX_UPDATE")

scanFrame:SetScript("OnEvent", function()
	if event == "PLAYER_LOGIN" then
		ScanBags()
	elseif event == "BAG_UPDATE" then
		ScanBags()
		if bankOpen then ScanBank() end
	elseif event == "BANKFRAME_OPENED" then
		bankOpen = true
		ScanBank()
	elseif event == "BANKFRAME_CLOSED" then
		bankOpen = false
	elseif event == "MAIL_SHOW" or event == "MAIL_INBOX_UPDATE" then
		ScanMail()
	end
end)

-- Safety net: BAG_UPDATE should fire the instant something moves between
-- bags and bank, but as a backstop (in case that event fires unreliably
-- for bank containers on this client), also poll a couple times a second
-- while the bank window is actually open. This guarantees the tooltip
-- never shows more than a fraction of a second of stale bank data.
local BANK_POLL_INTERVAL = 0.5
local pollElapsed = 0

scanFrame:SetScript("OnUpdate", function()
	if not bankOpen then return end
	local elapsed = arg1 or 0
	pollElapsed = pollElapsed + elapsed
	if pollElapsed >= BANK_POLL_INTERVAL then
		pollElapsed = 0
		ScanBank()
		ScanBags()
	end
end)

----------------------------------------------------------------------------
-- Tooltip augmentation
----------------------------------------------------------------------------

local function BuildInfoLines(itemID)
	if not itemID then return end

	local rows = {}
	local grandTotal = 0
	for charKey, data in pairs(ItemLocatorDB) do
		if charKey ~= "names" then
			local bags = (data.bags and data.bags[itemID]) or 0
			local bank = (data.bank and data.bank[itemID]) or 0
			local mail = (data.mail and data.mail[itemID]) or 0
			local transit = (data.transit and data.transit[itemID]) or 0
			local total = bags + bank + mail + transit
			if total > 0 then
				grandTotal = grandTotal + total
				local parts = {}
				if bags > 0 then table.insert(parts, bags .. " bags") end
				if bank > 0 then table.insert(parts, bank .. " bank") end
				if mail > 0 then table.insert(parts, mail .. " mail") end
				if transit > 0 then table.insert(parts, transit .. " in transit") end
				table.insert(rows, string.format("  %s: %d (%s)", charKey, total, table.concat(parts, ", ")))
			end
		end
	end

	if grandTotal == 0 then return end

	GameTooltip:AddLine(" ")
	GameTooltip:AddLine(string.format("Item Locator - Account Total: %d", grandTotal), 1, 0.82, 0)
	for _, line in ipairs(rows) do
		GameTooltip:AddLine(line, 1, 1, 1)
	end
	GameTooltip:Show()
end

-- Vanilla has no unified "OnTooltipSetItem" hook, so each tooltip source
-- function is individually wrapped to append our info after the original
-- tooltip content is built.

local orig_SetBagItem = GameTooltip.SetBagItem
GameTooltip.SetBagItem = function(self, bag, slot)
	orig_SetBagItem(self, bag, slot)
	BuildInfoLines(GetItemIDFromLink(GetContainerItemLink(bag, slot)))
end

local orig_SetInventoryItem = GameTooltip.SetInventoryItem
GameTooltip.SetInventoryItem = function(self, unit, slot)
	orig_SetInventoryItem(self, unit, slot)
	BuildInfoLines(GetItemIDFromLink(GetInventoryItemLink(unit, slot)))
end

local orig_SetHyperlink = GameTooltip.SetHyperlink
GameTooltip.SetHyperlink = function(self, link)
	orig_SetHyperlink(self, link)
	BuildInfoLines(GetItemIDFromLink(link))
end

local orig_SetMerchantItem = GameTooltip.SetMerchantItem
GameTooltip.SetMerchantItem = function(self, index)
	orig_SetMerchantItem(self, index)
	BuildInfoLines(GetItemIDFromLink(GetMerchantItemLink(index)))
end

local orig_SetLootItem = GameTooltip.SetLootItem
GameTooltip.SetLootItem = function(self, slot)
	orig_SetLootItem(self, slot)
	BuildInfoLines(GetItemIDFromLink(GetLootSlotLink(slot)))
end

if GameTooltip.SetInboxItem then
	local orig_SetInboxItem = GameTooltip.SetInboxItem
	GameTooltip.SetInboxItem = function(self, mailIndex, attachIndex)
		orig_SetInboxItem(self, mailIndex, attachIndex)
		BuildInfoLines(GetItemIDFromLink(GetInboxItemLink(mailIndex, attachIndex or 1)))
	end
end

if GameTooltip.SetAuctionItem then
	local orig_SetAuctionItem = GameTooltip.SetAuctionItem
	GameTooltip.SetAuctionItem = function(self, listType, index)
		orig_SetAuctionItem(self, listType, index)
		BuildInfoLines(GetItemIDFromLink(GetAuctionItemLink(listType, index)))
	end
end

----------------------------------------------------------------------------
-- Slash commands
----------------------------------------------------------------------------

SLASH_ITEMLOCATOR1 = "/itemlocator"
SLASH_ITEMLOCATOR2 = "/il"
SlashCmdList["ITEMLOCATOR"] = function(msg)
	msg = string.lower(msg or "")
	if msg == "scan" then
		ScanBags()
		if BankFrame and BankFrame:IsVisible() then ScanBank() end
		DEFAULT_CHAT_FRAME:AddMessage("ItemLocator: rescanned.")
	elseif msg == "reset" then
		ItemLocatorDB = { names = {} }
		DEFAULT_CHAT_FRAME:AddMessage("ItemLocator: all saved data cleared.")
	else
		DEFAULT_CHAT_FRAME:AddMessage("ItemLocator commands: /il scan, /il reset")
	end
end
